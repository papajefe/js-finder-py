"""Pokemon PRNG related enums"""
from .ds_type import DSType
from .game import Game
from .language import Language
